
------------
[Keil users]
------------

1. Copy keil/flashloader/* 
2. Paste to C:\KEIL\ARM\Flash folder.


------------
[IAR users]
------------

1. Copy iar/* directories
2. Paste to C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.3\arm\config\*


------------
[GCC users]
------------

1. Add toolchain path to the PATH variable

